package imobiliaria;
abstract class Imovel {
    String morada;
    double precoBase;
    double areaTotal;
    int id;
    static int incre = 100;

    public Imovel(String morada,double precoBase,double areaTotal){
        this.morada = morada;
        this.precoBase = precoBase;
        this.areaTotal = areaTotal;
        this.id += incre;
    }

    public String getMorada(){
        return morada;  
    }
    public double getPrecoBase(){
        return precoBase;
    }
    public double getareaTotal(){
        return areaTotal;
    }
    public void setMorada(String morada){
        this.morada = morada;  
    }
    public void setPrecoBase(double precoBase){
        this.precoBase = precoBase;
    }
    public void setareaTotal(double areaTotal){
        this.areaTotal = areaTotal;
    }
}
