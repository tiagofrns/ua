package Ex72;




public class App {

}
