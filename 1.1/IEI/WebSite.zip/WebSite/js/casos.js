function changeImage(i) {
    var imgElement = document.getElementById("imageDisplay");
    var imageNames = ["2guerra.png", "apple.png", "bitcoin.png", "quantica.png"];
    
    imgElement.src = "images/" + imageNames[i];
    
    setTimeout(function () {
        changeImage((i + 1) % imageNames.length);
    }, 3000);
}

changeImage(0);