var type = "bar";

function graphic(element) {
    var e = document.getElementById("selection");
    type = e.options[e.selectedIndex].value;
}

function draw() {
    $("#graph").highcharts({
        chart: { type: type },
        title: { text: "Perdas Monetárias" },
        xAxis: { categories: ["2020", "2021", "2022", "2023"] },
        yAxis: { title: { text: "Trilhões de Dólares" } },
        series:[
            {
                name: "Perdas Monetárias",
                data: [2.95, 5.49, 7.08, 8.15]
            }
        ]
    });
}